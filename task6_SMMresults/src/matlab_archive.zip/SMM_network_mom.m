function mom = SMM_network_mom(beta,prm,draws)

[ss mom] = SMM_network(beta,prm,draws);
end